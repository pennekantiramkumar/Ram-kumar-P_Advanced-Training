package com.hari.training;

public abstract class Instrument {
	public abstract void play();
}
